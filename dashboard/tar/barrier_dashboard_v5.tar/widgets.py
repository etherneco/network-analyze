import math
import requests
import threading
import time
from typing import Dict
from PyQt6 import QtCore, QtGui, QtWidgets

def human_size(bytesize: float) -> str:
    step = 1024.0
    units = ["B", "KB", "MB", "GB", "TB"]
    v = float(bytesize)
    i = 0
    while v >= step and i < len(units)-1:
        v /= step
        i += 1
    return f"{v:.1f}{units[i]}"

class LoadingSpinner(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(40, 40)
        self._angle = 0
        self._timer = QtCore.QTimer(self)
        self._timer.setInterval(40)
        self._timer.timeout.connect(self._rotate)
        self._timer.start()
        self._color = QtGui.QColor("#2A6CFF")

    def _rotate(self):
        if self.isVisible():
            self._angle = (self._angle + 15) % 360
            self.update()

    def setColor(self, hex_color):
        self._color = QtGui.QColor(hex_color)
        self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(4, 4, -4, -4)
        pen = QtGui.QPen(self._color)
        pen.setWidth(4)
        pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        start_angle = -self._angle * 16
        span_angle = 270 * 16
        painter.drawArc(rect, start_angle, span_angle)

class CircularGauge(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._value = 0.0
        self._display_value = 0.0
        self._animation_timer = QtCore.QTimer(self)
        self._animation_timer.setInterval(16)
        self._animation_timer.timeout.connect(self._animate_step)
        self._target = 0.0
        self._step = 0.0
        self.setMinimumSize(200, 200)
        self._label_font = QtGui.QFont("Inter", 28, QtGui.QFont.Weight.Bold)

    def setValue(self, v: float):
        v = max(0.0, min(100.0, float(v)))
        self._target = v
        diff = self._target - self._display_value
        steps = max(8, min(60, int(abs(diff) / 0.5) + 8))
        self._step = diff / steps
        if not self._animation_timer.isActive():
            self._animation_timer.start()

    def _animate_step(self):
        if abs(self._display_value - self._target) < abs(self._step) + 0.01:
            self._display_value = self._target
            self._animation_timer.stop()
        else:
            self._display_value += self._step
        self.update()

    def paintEvent(self, event):
        r = self.rect()
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        side = min(r.width(), r.height())
        center = r.center()
        radius = side * 0.38
        rect = QtCore.QRectF(center.x()-radius, center.y()-radius, radius*2, radius*2)
        pen = QtGui.QPen(QtGui.QColor("#1A1C1E"))
        pen.setWidthF(radius * 0.18)
        painter.setPen(pen)
        painter.drawEllipse(rect)
        pen.setColor(QtGui.QColor("#2A6CFF"))
        painter.setPen(pen)
        start_angle = 90 * 16
        span_angle = int(-self._display_value / 100.0 * 360.0 * 16)
        painter.drawArc(rect, start_angle, span_angle)
        painter.setPen(QtGui.QColor("#E6E8EB"))
        painter.setFont(self._label_font)
        text = f"{int(round(self._display_value))}%"
        painter.drawText(rect, QtCore.Qt.AlignmentFlag.AlignCenter, text)

class MemoryBar(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._percent = 0.0
        self._display = 0.0
        self._timer = QtCore.QTimer(self)
        self._timer.setInterval(20)
        self._timer.timeout.connect(self._step)
        self._target = 0.0

    def setPercent(self, p: float):
        p = max(0.0, min(100.0, float(p)))
        self._target = p
        self._step_delta = (self._target - self._display) / 15.0
        if not self._timer.isActive():
            self._timer.start()

    def _step(self):
        if abs(self._display - self._target) < abs(self._step_delta) + 0.01:
            self._display = self._target
            self._timer.stop()
        else:
            self._display += self._step_delta
        self.update()

    def paintEvent(self, event):
        r = self.rect()
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        bg_rect = QtCore.QRectF(0, r.height()*0.25, r.width(), r.height()*0.5)
        painter.setPen(QtCore.Qt.PenStyle.NoPen)
        painter.setBrush(QtGui.QColor("#2B2F33"))
        painter.drawRoundedRect(bg_rect, 6, 6)
        fill_w = bg_rect.width() * (self._display/100.0)
        fill_rect = QtCore.QRectF(bg_rect.x(), bg_rect.y(), fill_w, bg_rect.height())
        painter.setBrush(QtGui.QColor("#FFD300"))
        painter.drawRoundedRect(fill_rect, 6, 6)
        painter.setPen(QtGui.QColor("#E6E8EB"))
        font = painter.font()
        font.setPointSize(14)
        painter.setFont(font)
        painter.drawText(r, QtCore.Qt.AlignmentFlag.AlignCenter, f"{int(round(self._display))}% used")

class DiskList(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.disks = {}
        self.setMinimumWidth(250)
        # Ustawiamy minimalną wysokość startową
        self.setMinimumHeight(100)

    def setDisks(self, d: Dict[str, Dict[str, float]]):
        self.disks = d or {}
        # Dynamicznie obliczamy wysokość widgetu
        # 60px na każdy dysk + marginesy
        row_height = 60
        total_height = max(100, len(self.disks) * row_height + 20)
        self.setMinimumHeight(total_height)
        self.update()

    def paintEvent(self, event):
        r = self.rect()
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        
        font_main = painter.font()
        font_main.setPointSize(12)
        font_main.setBold(True)
        
        font_sub = painter.font()
        font_sub.setPointSize(10)
        font_sub.setBold(False)

        y = 5
        row_height = 60
        
        if not self.disks:
            painter.setPen(QtGui.QColor("#9FA3A7"))
            painter.setFont(font_sub)
            painter.drawText(r, QtCore.Qt.AlignmentFlag.AlignCenter, "No partitions found")
            return

        for mount, info in self.disks.items():
            used = info.get("used", 0.0)
            total = info.get("total", 1.0)
            percent = 0.0 if total == 0 else (used / total) * 100.0
            
            # --- Wiersz 1: Nazwa i Pojemność ---
            
            # 1. Mount Point (Do lewej)
            painter.setFont(font_main)
            painter.setPen(QtGui.QColor("#E6E8EB"))
            left_rect = QtCore.QRectF(10, y + 2, r.width()/2, 20)
            painter.drawText(left_rect, QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignVCenter, str(mount))
            
            # 2. Capacity (Do prawej)
            cap_text = f"{human_size(used)} / {human_size(total)}"
            painter.setFont(font_sub)
            painter.setPen(QtGui.QColor("#9FA3A7"))
            right_rect = QtCore.QRectF(10, y + 2, r.width()-20, 20)
            painter.drawText(right_rect, QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter, cap_text)

            # --- Wiersz 2: Pasek i Procenty ---
            bar_y = y + 28
            bar_height = 10
            
            # 3. Percent Text
            percent_text = f"{int(math.floor(percent))}%"
            painter.setFont(font_sub)
            painter.setPen(QtGui.QColor("#FFD300"))
            
            fm_pct = QtGui.QFontMetrics(font_sub)
            pct_width = fm_pct.horizontalAdvance(percent_text)
            
            # Rysuj tekst procentów
            painter.drawText(QtCore.QRectF(r.width() - pct_width - 10, bar_y, pct_width + 5, bar_height), 
                             QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter, 
                             percent_text)
            
            # 4. Bar
            bar_max_width = r.width() - pct_width - 25
            bar_rect = QtCore.QRectF(10, bar_y, bar_max_width, bar_height)
            
            painter.setPen(QtCore.Qt.PenStyle.NoPen)
            painter.setBrush(QtGui.QColor("#2B2F33"))
            painter.drawRoundedRect(bar_rect, 4, 4)
            
            painter.setBrush(QtGui.QColor("#2A6CFF"))
            fill_w = bar_rect.width() * (min(100.0, percent)/100.0)
            if fill_w > 0:
                painter.drawRoundedRect(QtCore.QRectF(bar_rect.x(), bar_rect.y(), fill_w, bar_rect.height()), 4, 4)

            y += row_height

class ScreenshotGallery(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QtWidgets.QGridLayout(self)
        self.layout.setSpacing(10)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.labels = []
        
        for i in range(10):
            lbl = QtWidgets.QLabel()
            lbl.setStyleSheet("background-color: #1A1C1E; border-radius: 6px; border: 1px solid #2B2F33;")
            lbl.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            lbl.setScaledContents(True)
            lbl.setMinimumSize(120, 80)
            lbl.setText(f"Screen {i+1}\nLoading...")
            lbl.setStyleSheet("color: #555; font-size: 10px; border: 1px dashed #333;")
            
            row = i // 5
            col = i % 5
            self.layout.addWidget(lbl, row, col)
            self.labels.append(lbl)

        threading.Thread(target=self._fetch_placeholders, daemon=True).start()

    def _fetch_placeholders(self):
        for i, lbl in enumerate(self.labels):
            try:
                url = f"https://picsum.photos/240/160?random={i+100}"
                r = requests.get(url, timeout=2.0)
                if r.status_code == 200:
                    pixmap = QtGui.QPixmap()
                    pixmap.loadFromData(r.content)
                    QtCore.QMetaObject.invokeMethod(lbl, "setPixmap", QtCore.Qt.ConnectionType.QueuedConnection, QtCore.Q_ARG(QtGui.QPixmap, pixmap))
                    QtCore.QMetaObject.invokeMethod(lbl, "setStyleSheet", QtCore.Qt.ConnectionType.QueuedConnection, QtCore.Q_ARG(str, "border: 2px solid #2A6CFF; border-radius: 4px;"))
            except Exception:
                pass
            time.sleep(0.15)
