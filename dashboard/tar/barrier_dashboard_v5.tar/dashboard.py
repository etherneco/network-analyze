import time
import threading
from PyQt6 import QtCore, QtWidgets

import network_data as nd
from widgets import LoadingSpinner, CircularGauge, MemoryBar, DiskList, ScreenshotGallery, human_size
from commander import CommanderPanel

REFRESH_INTERVAL_SEC = 2.0

class DashboardWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Barrier Monitor Dashboard")
        self.setStyleSheet(self._base_stylesheet())
        self.setMinimumSize(1400, 800)
        
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        
        main_layout = QtWidgets.QVBoxLayout(central)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(15)
        
        # --- TOP BAR ---
        top_bar = QtWidgets.QHBoxLayout()
        top_bar.addStretch()
        self.time_label = QtWidgets.QLabel("--:--:--")
        self.time_label.setObjectName("timeLabel")
        top_bar.addWidget(self.time_label)
        main_layout.addLayout(top_bar)
        
        # --- HEADER ---
        header_container = QtWidgets.QWidget()
        header_layout = QtWidgets.QHBoxLayout(header_container)
        header_layout.setContentsMargins(0, 10, 0, 30)
        header_layout.setSpacing(20)
        header_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        
        self.spinner = LoadingSpinner()
        header_layout.addWidget(self.spinner)
        
        text_container = QtWidgets.QWidget()
        text_layout = QtWidgets.QVBoxLayout(text_container)
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(2)
        
        self.big_host_label = QtWidgets.QLabel("DETECTING...")
        self.big_host_label.setObjectName("bigHost")
        self.big_host_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
        
        self.ip_label = QtWidgets.QLabel("Searching for Barrier server...")
        self.ip_label.setObjectName("ipLabel")
        self.ip_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
        
        text_layout.addWidget(self.big_host_label)
        text_layout.addWidget(self.ip_label)
        
        header_layout.addWidget(text_container)
        main_layout.addWidget(header_container)
        
        # --- PANELS (3 Columns) ---
        self.panels_widget = QtWidgets.QWidget()
        panels_layout = QtWidgets.QHBoxLayout(self.panels_widget)
        panels_layout.setSpacing(20)
        panels_layout.setContentsMargins(0,0,0,0)

        # COLUMN 1: CPU + MEMORY (Left)
        col1_widget = QtWidgets.QWidget()
        col1_layout = QtWidgets.QVBoxLayout(col1_widget)
        col1_layout.setContentsMargins(0,0,0,0)
        col1_layout.setSpacing(15)

        cpu_card = QtWidgets.QFrame()
        cpu_card.setObjectName("card")
        cpu_layout = QtWidgets.QVBoxLayout(cpu_card)
        cpu_title = QtWidgets.QLabel("CPU")
        cpu_title.setObjectName("title")
        cpu_layout.addWidget(cpu_title)
        self.gauge = CircularGauge()
        cpu_layout.addWidget(self.gauge, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)
        self.cpu_info = QtWidgets.QLabel("Cores: -   Load: -")
        cpu_layout.addWidget(self.cpu_info)
        col1_layout.addWidget(cpu_card)

        mem_card = QtWidgets.QFrame()
        mem_card.setObjectName("card")
        mem_layout = QtWidgets.QVBoxLayout(mem_card)
        mem_title = QtWidgets.QLabel("Memory")
        mem_title.setObjectName("title")
        mem_layout.addWidget(mem_title)
        self.membar = MemoryBar()
        self.membar.setFixedHeight(70)
        mem_layout.addWidget(self.membar)
        self.mem_info = QtWidgets.QLabel("0 / 0")
        mem_layout.addWidget(self.mem_info)
        col1_layout.addWidget(mem_card)
        
        panels_layout.addWidget(col1_widget, 1)

        # COLUMN 2: SCREENSHOTS (Middle)
        screens_card = QtWidgets.QFrame()
        screens_card.setObjectName("card")
        screens_layout = QtWidgets.QVBoxLayout(screens_card)
        screens_title = QtWidgets.QLabel("Active Screens (Live)")
        screens_title.setObjectName("title")
        screens_layout.addWidget(screens_title)
        self.gallery = ScreenshotGallery()
        screens_layout.addWidget(self.gallery)
        panels_layout.addWidget(screens_card, 2)

        # COLUMN 3: DISK + COMMANDER (Right)
        col3_widget = QtWidgets.QWidget()
        col3_layout = QtWidgets.QVBoxLayout(col3_widget)
        col3_layout.setContentsMargins(0,0,0,0)
        col3_layout.setSpacing(15)

        disk_card = QtWidgets.QFrame()
        disk_card.setObjectName("card")
        disk_layout = QtWidgets.QVBoxLayout(disk_card)
        disk_title = QtWidgets.QLabel("Disk Storage")
        disk_title.setObjectName("title")
        disk_layout.addWidget(disk_title)
        self.disk_list = DiskList()
        disk_layout.addWidget(self.disk_list)
        col3_layout.addWidget(disk_card)

        commander_card = QtWidgets.QFrame()
        commander_card.setObjectName("card")
        commander_layout = QtWidgets.QVBoxLayout(commander_card)
        commander_title = QtWidgets.QLabel("Commander")
        commander_title.setObjectName("title")
        commander_layout.addWidget(commander_title)
        self.commander = CommanderPanel(status_setter=self._set_status)
        commander_layout.addWidget(self.commander)
        col3_layout.addWidget(commander_card)

        panels_layout.addWidget(col3_widget, 1)

        main_layout.addWidget(self.panels_widget)
        self.panels_widget.setVisible(False)
        
        # --- STATUS ---
        self.status = QtWidgets.QLabel("Initializing...")
        main_layout.addWidget(self.status)
        
        # --- STATE ---
        self._metrics = None
        self._current_host = None
        self._current_ip = None
        self._fetch_lock = threading.Lock()
        
        self._clock_timer = QtCore.QTimer(self)
        self._clock_timer.setInterval(1000)
        self._clock_timer.timeout.connect(self._update_clock)
        self._clock_timer.start()
        
        self._refresh_timer = QtCore.QTimer(self)
        self._refresh_timer.setInterval(int(REFRESH_INTERVAL_SEC * 1000))
        self._refresh_timer.timeout.connect(self._trigger_fetch)
        self._refresh_timer.start()
        self._trigger_fetch()

    def _base_stylesheet(self):
        return """
        QWidget { background: #101214; color: #E6E8EB; font-family: Inter, Arial; }
        #card { background: #131517; border-radius: 12px; padding: 12px; }
        #title { font-size: 20px; font-weight: 600; color: #E6E8EB; margin-bottom: 5px; }
        #bigHost { font-size: 36px; font-weight: 700; color: #FFFFFF; letter-spacing: 1px; }
        #ipLabel { font-size: 16px; font-weight: 400; color: #9FA3A7; }
        #timeLabel { font-size: 16px; color: #B4B9BD; }
        QLabel { color: #C8CDD0; }
        """

    def _set_status(self, text: str):
        try:
            QtCore.QMetaObject.invokeMethod(self.status, "setText", QtCore.Qt.ConnectionType.QueuedConnection, QtCore.Q_ARG(str, text))
        except Exception:
            try:
                self.status.setText(text)
            except Exception:
                pass

    def _update_clock(self):
        self.time_label.setText(time.strftime("%H:%M:%S"))

    def _trigger_fetch(self):
        t = threading.Thread(target=self._fetch_cycle, daemon=True)
        t.start()

    def _fetch_cycle(self):
        with self._fetch_lock:
            info = nd.fetch_host_info()
            if info:
                self._current_host, self._current_ip = info
            
            new_metrics = None
            if self._current_ip:
                new_metrics = nd.fetch_remote_metrics(self._current_ip, self._current_host)
            
            QtCore.QMetaObject.invokeMethod(self, "_apply_state", QtCore.Qt.ConnectionType.QueuedConnection, QtCore.Q_ARG(object, new_metrics))

    @QtCore.pyqtSlot(object)
    def _apply_state(self, metrics: nd.Metrics):
        self._metrics = metrics
        
        if metrics:
            self.spinner.setVisible(False)
            self.panels_widget.setVisible(True)
            self.big_host_label.setText(self._current_host)
            self.big_host_label.setStyleSheet("")
            self.ip_label.setText(self._current_ip)
            self.ip_label.setStyleSheet("#ipLabel { color: #9FA3A7; }")
            
            self.gauge.setValue(metrics.cpu_percent)
            self.membar.setPercent(metrics.memory_percent())
            
            cores = metrics.cores
            try:
                self.cpu_info.setText(f"Cores: {cores}   Load: {metrics.cpu_percent:.0f}%")
            except Exception:
                self.cpu_info.setText(f"Cores: {cores}   Load: {int(metrics.cpu_percent)}%")
                
            try:
                self.mem_info.setText(f"{human_size(metrics.memory_used)} / {human_size(metrics.memory_total)}")
            except Exception:
                self.mem_info.setText("N/A")
                
            self.disk_list.setDisks(metrics.disks or {})
            self.status.setText(f"Status: Online — Updated: {time.strftime('%H:%M:%S')}")
            
            try:
                self.commander.setTarget(self._current_host, self._current_ip)
            except Exception:
                pass
        else:
            self.spinner.setVisible(True)
            self.panels_widget.setVisible(False)
            
            if self._current_host:
                self.big_host_label.setText(self._current_host)
                self.ip_label.setText(f"{self._current_ip} (Connection Failed)")
                self.spinner.setColor("#FF5555")
                self.ip_label.setStyleSheet("color: #FF5555;")
                self.status.setText("Status: Host found, but metrics unavailable")
                try:
                    self.commander.setTarget(self._current_host, self._current_ip)
                except Exception:
                    pass
            else:
                self.big_host_label.setText("SEARCHING...")
                self.ip_label.setText("Waiting for Barrier...")
                self.spinner.setColor("#FFD300")
                self.ip_label.setStyleSheet("color: #FFD300;")
                self.status.setText("Status: Scanning network...")
