import requests
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

BARRIER_URL = "http://10.1.1.1:24802/current"

COMMANDS = {
    "enoch": [
        {"label": "CHROME", "cmd": "run_chrome"},
        {"label": "REBOOT", "cmd": "reboot_now"},
    ],
    "metrix": [
        {"label": "compile DI", "cmd": "magento_compile_di"},
        {"label": "flush cache", "cmd": "magento_cache_flush"},
    ],
    "lod": [
        {"label": "Open Logs", "cmd": "date > /home/daniel/last_call"},
    ]
}

@dataclass
class Metrics:
    cpu_percent: float = 0.0
    cores: int = 0
    memory_used: float = 0.0
    memory_total: float = 1.0
    swap_used: float = 0.0
    swap_total: float = 1.0
    disks: Dict[str, Dict[str, float]] = None

    def memory_percent(self):
        return 0.0 if self.memory_total == 0 else (self.memory_used / self.memory_total) * 100.0

def fetch_host_info() -> Optional[Tuple[str, str]]:
    try:
        r = requests.get(BARRIER_URL, timeout=1.2)
        r.raise_for_status()
        data = r.json()
        server = data.get("server", {})
        name = server.get("current")
        ip = server.get("ip")
        if name and ip:
            return (name, ip)
        return None
    except Exception:
        return None

def fetch_remote_metrics(ip: str, hostname: str) -> Optional[Metrics]:
    try:
        url = f"http://{ip}:28000/metrics?host={hostname}"
        r = requests.get(url, timeout=1.0)
        r.raise_for_status()
        data = r.json()
        
        m = Metrics()
        cpu = data.get("cpu", {})
        m.cpu_percent = float(cpu.get("usage_percent", 0.0))
        m.cores = cpu.get("cores", 0)
        
        mem = data.get("memory", {})
        m.memory_used = float(mem.get("used", 0.0))
        m.memory_total = float(mem.get("total", 1.0))
        
        swap = data.get("swap", {})
        m.swap_used = float(swap.get("used", 0.0))
        m.swap_total = float(swap.get("total", 1.0))
        
        m.disks = data.get("disks", {})
        return m
    except Exception:
        return None

def send_command_to_server(ip: str, host: str, cmd: str) -> str:
    try:
        url = f"http://{ip}:28000/command"
        payload = {"host": host, "cmd": cmd}
        r = requests.post(url, json=payload, timeout=3.0)
        try:
            r.raise_for_status()
            resp = r.json() if r.headers.get("Content-Type", "").startswith("application/json") else {"status": "ok"}
            return resp.get("message", "Command sent")
        except Exception:
            return f"HTTP {r.status_code}"
    except Exception as e:
        return str(e)
