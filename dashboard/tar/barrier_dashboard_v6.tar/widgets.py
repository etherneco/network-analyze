import math
import requests
import threading
import time
from typing import Dict, List
from PyQt6 import QtCore, QtGui, QtWidgets

def human_size(bytesize: float) -> str:
    step = 1024.0
    units = ["B", "KB", "MB", "GB", "TB"]
    v = float(bytesize)
    i = 0
    while v >= step and i < len(units)-1:
        v /= step
        i += 1
    return f"{v:.1f}{units[i]}"

# --- Spinner, Gauge, MemoryBar, DiskList (Skrócone dla oszczędności miejsca w kodzie, ale działające) ---
class LoadingSpinner(QtWidgets.QWidget):
    def __init__(self, p=None): super().__init__(p); self.setFixedSize(40,40); self._a=0; self._t=QtCore.QTimer(self); self._t.timeout.connect(self._r); self._t.start(40); self._c=QtGui.QColor("#2A6CFF")
    def _r(self): 
        if self.isVisible(): self._a=(self._a+15)%360; self.update()
    def setColor(self, c): self._c=QtGui.QColor(c); self.update()
    def paintEvent(self, e): p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing); r=self.rect().adjusted(4,4,-4,-4); pen=QtGui.QPen(self._c); pen.setWidth(4); pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap); p.setPen(pen); p.drawArc(r,-self._a*16, 270*16)

class CircularGauge(QtWidgets.QWidget):
    def __init__(self, p=None): super().__init__(p); self._v=0.0; self._t=0.0; self._tm=QtCore.QTimer(self); self._tm.timeout.connect(self._a); self.setMinimumSize(200,200)
    def setValue(self, v): self._t=max(0,min(100,float(v))); self._tm.start(16)
    def _a(self): 
        if abs(self._v-self._t)<0.1: self._v=self._t; self._tm.stop()
        else: self._v+=(self._t-self._v)*0.1
        self.update()
    def paintEvent(self, e):
        p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing); r=self.rect(); s=min(r.width(),r.height()); rad=s*0.38; rect=QtCore.QRectF(r.center().x()-rad, r.center().y()-rad, rad*2, rad*2)
        p.setPen(QtGui.QPen(QtGui.QColor("#1A1C1E"), rad*0.18)); p.drawEllipse(rect)
        p.setPen(QtGui.QPen(QtGui.QColor("#2A6CFF"), rad*0.18)); p.drawArc(rect, 90*16, int(-self._v/100*360*16))
        p.setPen(QtGui.QColor("#E6E8EB")); f=p.font(); f.setPointSize(28); f.setBold(True); p.setFont(f); p.drawText(rect, QtCore.Qt.AlignmentFlag.AlignCenter, f"{int(self._v)}%")

class MemoryBar(QtWidgets.QWidget):
    def __init__(self, p=None): super().__init__(p); self._v=0; self._t=0; self._tm=QtCore.QTimer(self); self._tm.timeout.connect(self._a)
    def setPercent(self, v): self._t=max(0,min(100,float(v))); self._tm.start(20)
    def _a(self):
        if abs(self._v-self._t)<0.1: self._v=self._t; self._tm.stop()
        else: self._v+=(self._t-self._v)*0.1
        self.update()
    def paintEvent(self, e):
        r=self.rect(); p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        bg=QtCore.QRectF(0, r.height()*0.25, r.width(), r.height()*0.5)
        p.setBrush(QtGui.QColor("#2B2F33")); p.setPen(QtCore.Qt.PenStyle.NoPen); p.drawRoundedRect(bg,6,6)
        p.setBrush(QtGui.QColor("#FFD300")); p.drawRoundedRect(QtCore.QRectF(bg.x(), bg.y(), bg.width()*(self._v/100), bg.height()),6,6)
        p.setPen(QtGui.QColor("#E6E8EB")); f=p.font(); f.setPointSize(14); p.setFont(f); p.drawText(r, QtCore.Qt.AlignmentFlag.AlignCenter, f"{int(self._v)}% used")

class DiskList(QtWidgets.QWidget):
    def __init__(self, p=None): super().__init__(p); self.disks={}; self.setMinimumWidth(250); self.setMinimumHeight(100)
    def setDisks(self, d): self.disks=d or {}; self.setMinimumHeight(max(100, len(self.disks)*60+20)); self.update()
    def paintEvent(self, e):
        r=self.rect(); p=QtGui.QPainter(self); p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        fm=p.font(); fm.setPointSize(12); fm.setBold(True); fs=p.font(); fs.setPointSize(10); y=5
        if not self.disks: p.setPen(QtGui.QColor("#9FA3A7")); p.drawText(r, QtCore.Qt.AlignmentFlag.AlignCenter, "No partitions"); return
        for m,i in self.disks.items():
            u,t=i.get("used",0), i.get("total",1); pct=0 if t==0 else (u/t)*100
            p.setFont(fm); p.setPen(QtGui.QColor("#E6E8EB")); p.drawText(QtCore.QRectF(10,y+2,r.width()/2,20), QtCore.Qt.AlignmentFlag.AlignLeft|QtCore.Qt.AlignmentFlag.AlignVCenter, str(m))
            p.setFont(fs); p.setPen(QtGui.QColor("#9FA3A7")); cap=f"{human_size(u)} / {human_size(t)}"; p.drawText(QtCore.QRectF(10,y+2,r.width()-20,20), QtCore.Qt.AlignmentFlag.AlignRight|QtCore.Qt.AlignmentFlag.AlignVCenter, cap)
            by=y+28; p.setPen(QtGui.QColor("#FFD300")); tw=QtGui.QFontMetrics(fs).horizontalAdvance(f"{int(pct)}%")
            p.drawText(QtCore.QRectF(r.width()-tw-10, by, tw+5, 10), QtCore.Qt.AlignmentFlag.AlignRight|QtCore.Qt.AlignmentFlag.AlignVCenter, f"{int(pct)}%")
            br=QtCore.QRectF(10,by,r.width()-tw-25,10); p.setPen(QtCore.Qt.PenStyle.NoPen); p.setBrush(QtGui.QColor("#2B2F33")); p.drawRoundedRect(br,4,4)
            fw=br.width()*(min(100,pct)/100); p.setBrush(QtGui.QColor("#2A6CFF")); 
            if fw>0: p.drawRoundedRect(QtCore.QRectF(br.x(),br.y(),fw,br.height()),4,4)
            y+=60

# --- NOWOŚĆ: PROCESS GALLERY ---

class ProcessCard(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QtWidgets.QVBoxLayout(self)
        self.layout.setContentsMargins(0,0,0,0)
        self.layout.setSpacing(2)
        
        # Obrazek
        self.image_label = QtWidgets.QLabel()
        self.image_label.setScaledContents(True)
        self.image_label.setStyleSheet("background-color: #000; border-radius: 4px; border: 1px solid #333;")
        self.image_label.setMinimumSize(140, 90)
        self.image_label.setMaximumSize(140, 90)
        self.layout.addWidget(self.image_label)
        
        # Nazwa PID
        self.info_label = QtWidgets.QLabel("Loading...")
        self.info_label.setStyleSheet("color: #AAA; font-size: 10px; font-weight: bold;")
        self.info_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(self.info_label)
        
        self.pid = None
        self.pname = ""

    def update_info(self, pid, name, mem):
        self.pid = pid
        self.pname = name
        # Skracanie nazwy
        disp_name = (name[:12] + '..') if len(name) > 12 else name
        self.info_label.setText(f"{disp_name} ({pid})")

    def set_pixmap(self, pixmap):
        self.image_label.setPixmap(pixmap)
        self.image_label.setStyleSheet("background-color: #000; border-radius: 4px; border: 1px solid #2A6CFF;")

class ProcessGallery(QtWidgets.QScrollArea):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        self.setStyleSheet("QScrollArea { background: transparent; } QScrollBar { background: #131517; }")
        
        self.container = QtWidgets.QWidget()
        self.container.setStyleSheet("background: transparent;")
        self.grid = QtWidgets.QGridLayout(self.container)
        self.grid.setSpacing(10)
        self.grid.setContentsMargins(0,0,0,0)
        self.setWidget(self.container)
        
        self.cards = []
        self._ip = None
        self._running = True
        
        # Tworzymy pulę 21 kafelków (3 kolumny x 7 rzędów)
        # Dzięki temu nie musimy ciągle tworzyć/usuwać widgetów
        max_cards = 21
        cols = 3
        for i in range(max_cards):
            card = ProcessCard()
            card.setVisible(False) # Na start ukryte
            row = i // cols
            col = i % cols
            self.grid.addWidget(card, row, col)
            self.cards.append(card)

        # Wątek "Kolejno odlicz"
        self._thread = threading.Thread(target=self._update_loop, daemon=True)
        self._thread.start()

    def set_data(self, ip: str, processes: List[Dict]):
        self._ip = ip
        
        # Aktualizujemy widgety danymi procesów
        for i, card in enumerate(self.cards):
            if i < len(processes):
                p = processes[i]
                card.update_info(p['pid'], p['name'], p.get('mem', 0))
                card.setVisible(True)
            else:
                card.setVisible(False)
                card.pid = None # Zaznaczamy jako nieaktywny

    def _update_loop(self):
        while self._running:
            if self._ip:
                active_cards = [c for c in self.cards if c.isVisible() and c.pid is not None]
                
                if not active_cards:
                    time.sleep(1)
                    continue

                for card in active_cards:
                    # Sprawdzamy czy IP nadal aktualne (mogło się zmienić w trakcie pętli)
                    if not self._ip: break
                    
                    try:
                        # Pobieramy screenshot dla konkretnego PID
                        url = f"http://{self._ip}:28000/screenshot/{card.pid}"
                        r = requests.get(url, timeout=1.0) # Krótki timeout
                        
                        if r.status_code == 200:
                            pixmap = QtGui.QPixmap()
                            pixmap.loadFromData(r.content)
                            # Aktualizacja GUI
                            QtCore.QMetaObject.invokeMethod(card, "set_pixmap", QtCore.Qt.ConnectionType.QueuedConnection, QtCore.Q_ARG(QtGui.QPixmap, pixmap))
                    except Exception:
                        pass
                    
                    # Czekamy chwilę przed następnym kafelkiem (efekt kolejno odlicz + oszczędzanie łącza)
                    time.sleep(0.3) 
                
                # Po przejściu całej listy czekamy chwilę dłużej
                time.sleep(1.0)
            else:
                time.sleep(1)
